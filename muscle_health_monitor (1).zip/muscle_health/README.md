# 🧍 AI Muscle Strain & Posture Monitoring System

## Project Structure

```
muscle_health/
├── backend/
│   ├── app.py              ← Flask REST API
│   ├── model.pkl           ← RandomForest classifier
│   ├── label_encoder.pkl   ← Sklearn LabelEncoder
│   └── requirements.txt
├── frontend/
│   ├── app.py              ← Streamlit UI
│   └── requirements.txt
└── README.md
```

---

## ⚙️ Setup & Run

### Step 1 — Install backend dependencies

```bash
cd backend
pip install -r requirements.txt
```

### Step 2 — Start the Flask backend

```bash
python app.py
```

The API will start at **http://localhost:5000**

---

### Step 3 — Install frontend dependencies (new terminal)

```bash
cd frontend
pip install -r requirements.txt
```

### Step 4 — Start the Streamlit frontend

```bash
streamlit run app.py
```

The UI will open at **http://localhost:8501**

---

## 🔌 API Reference

### `GET /`
Health check — returns `{"status": "ok"}`

### `POST /predict`

**Request body (JSON):**
```json
{
  "acc_x": 0.0,
  "acc_y": 0.0,
  "acc_z": 9.8,
  "gyro_x": 0.0,
  "gyro_y": 0.0,
  "gyro_z": 0.0,
  "emg_ch1": 0.2,
  "emg_ch2": 0.2,
  "emg_ch3": 0.2,
  "emg_ch4": 0.2
}
```

**Response:**
```json
{
  "prediction": "Biceps Strain, Back Strain",
  "confidence": 0.87,
  "affected_areas": ["Biceps Strain", "Back Strain"]
}
```

---

## 🏷️ Possible Predictions

| Label | Meaning |
|---|---|
| Normal | No strain detected |
| Biceps Strain | Biceps muscle overloaded |
| Triceps Strain | Triceps muscle overloaded |
| Back Strain | Back / lumbar stress |
| Leg Strain | Leg muscles under stress |
| Combinations | e.g. "Biceps Strain, Back Strain" |

---

## 🌿 SDG 3 — Good Health & Well-being
This system supports real-time musculoskeletal health monitoring using IMU and EMG sensor data.
